import tkinter
from tkinter import CENTER, INSERT, Button, scrolledtext
from turtle import pos
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import math


# Criação de classes e funções #

class Robo:
    def __init__(self, posx_init, posy_init):
        self.aceleracao = 0
        self.ax = 0
        self.ay = 0
        self.velx = 0
        self.vely = 0
        self.posy = posy_init
        self.posx = posx_init
        self.i = 0

    def grafico(x, y, titulo="Gráfico", cor='blue', xlabel="CX", ylabel="CY"):
        plt.show(block=False)
        figure = plt.figure(figsize=(6, 4.5), dpi=100)
        figure.add_subplot(111).plot(x, y, color=cor)
        chart = FigureCanvasTkAgg(figure, janela)
        chart.get_tk_widget().place(anchor=CENTER, relx=0.5, rely=0.47)
        plt.title(titulo)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.close("all")
    
    def perseguir(self):
        self.aceleracao = 2.8*tempo[1]
        self.deltax = abs(pos_x[self.i] - self.posx)**2
        print(self.deltax)

        self.deltay = abs(pos_y[self.i] - self.posy)**2
        print(self.deltay)
        somaDeltas = (self.deltax) + (self.deltay)
        print(somaDeltas)
        self.distancia = math.sqrt(somaDeltas)
        print(self.distancia)
        self.cos = (pos_x[self.i] - self.posx)/self.distancia
        self.sen = (pos_y[self.i] - self.posy)/self.distancia
        self.ax = self.cos*self.aceleracao
        self.ay = self.sen*self.aceleracao
        if (2.8 >= (self.velx + self.ax)):
            self.velx += self.ax
        else:
            self.velx = 2.8
        
        if (2.8 >= (self.vely + self.ay)):
            self.vely+=self.ay
        else:
            self.vely = 2.8
        
        self.posx += self.velx
        self.posy += self.vely



def grafico1():
    Robo.grafico(pos_x, pos_y, "Trajetória da Bola", 'red', "Px", "Py")


def grafico2():
    Robo.grafico(tempo, pos_x, "V(x) da Bola", 'blue')


def grafico3():
    Robo.grafico(tempo, pos_y, "V(y) da Bola", 'green')

def grafico4():
    Robo.grafico(posx_robo, posy_robo, "Trajetoria do robo", 'purple')


# Criação da Janela + Interface #

janela = tkinter.Tk()

janela.title("Robo artilheiro")

janela.geometry("800x600")

campo_pos = scrolledtext.ScrolledText(janela, width=95, height=4)
campo_pos.place(relx=0.5, rely=0.93, anchor=CENTER)

botao1 = Button(janela, text="Gráfico da Trajetória", width=14, bg="red", fg='white', command=grafico1)
botao1.place(anchor=CENTER, relx=0.2, rely=0.05)

botao2 = Button(janela, text="Gráfico de V(x)", width=14, bg="blue", fg='white', command=grafico2)
botao2.place(anchor=CENTER, relx=0.5, rely=0.05)

botao3 = Button(janela, text="Gráfico de V(y)", width=14, bg="green", fg='white', command=grafico3)
botao3.place(anchor=CENTER, relx=0.8, rely=0.05)

botao4 = Button(janela, text="Trajetoria robo", width=14, bg="purple", fg="white", command=grafico4)
botao4.place(anchor=CENTER, relx=0.65, rely=0.05)

# Código (Lógica) responsável pelos dados #

trajetoria = open('trajetoriaMeio.txt', 'r')
lista_pos = []
pos_x = []
pos_y = []
tempo = []

for line in trajetoria:
    linha = line.replace("\t"," ").replace("\n"," ").replace(",", ".")
    linha2 = linha.split(" ")
    lista_pos.append(linha)
    tempo.append(linha2[0])
    pos_x.append((linha2[1]))
    pos_y.append((linha2[2]))

del pos_y[0], pos_x[0], tempo[0]

for indice in range(len(pos_x)):
    pos_x[indice] = float(pos_x[indice]) - 1
    pos_y[indice] = float(pos_y[indice])
    tempo[indice] = float(tempo[indice])

trajetoria.close()

robo = Robo(0.5, 0.6)

posx_robo = []
posy_robo = []

while True:
    posx_robo.append(robo.posx)
    posy_robo.append(robo.posy)
    
    robo.perseguir()
    robo.i+=1
    
    if robo.i >= len(pos_x):
        break

for line in lista_pos:
    campo_pos.insert(INSERT, line)


janela.mainloop()