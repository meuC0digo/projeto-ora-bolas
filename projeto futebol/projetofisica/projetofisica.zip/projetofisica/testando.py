from sympy import *
import math

x, y, z = symbols('x y z')

print(diff(4*x**2 + 5*x + 15))